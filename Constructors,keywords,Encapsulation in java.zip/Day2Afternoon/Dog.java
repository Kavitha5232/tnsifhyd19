package com.Day2Afternoon;

public class Dog extends SuperInstance {
String color="black";
void printColor() {
	System.out.println(color);
	System.out.println(super.color);
	
}
}
