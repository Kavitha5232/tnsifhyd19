package com.Day2Afternoon;

public class SuperInstance {
	String color="white";
}


