package com.Day2Afternoon;

public class DogConstructor  extends SuperConstructor
{
	DogConstructor() {
		super();
		System.out.println("dog is created");
		
	}

}
