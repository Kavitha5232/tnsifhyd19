package com.Day2Afternoon;
public class AndhraBank implements BankAccount {
	
@Override	
public float rateofInterest() {
			// TODO Auto-generated method stub
			return 9.15f;
		}

	}
	
