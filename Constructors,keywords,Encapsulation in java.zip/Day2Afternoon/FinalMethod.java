package com.Day2Afternoon;

public class FinalMethod {
 final void run()
{
	System.out.println("running");
}

}