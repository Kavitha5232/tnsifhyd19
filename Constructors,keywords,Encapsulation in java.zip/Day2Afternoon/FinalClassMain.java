package com.Day2Afternoon;

public class FinalClassMain extends FinalClass {
	void run() {
		System.out.println("running safely with 100kmph");}  
    
	  public static void main(String args[]){  
	  FinalClassMain fcm= new FinalClassMain();  
	  fcm.run();  
	  }  
	
	
	}
	


