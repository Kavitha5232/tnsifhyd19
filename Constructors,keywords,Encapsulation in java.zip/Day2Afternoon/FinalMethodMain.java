package com.Day2Afternoon;

public class FinalMethodMain extends FinalMethod
{
void run() {
	System.out.println("running safely with 100kph");
}
public static void main(String[] args) {
	FinalMethodMain fmm=new FinalMethodMain();
	fmm.run();
	
	
}
	
}

