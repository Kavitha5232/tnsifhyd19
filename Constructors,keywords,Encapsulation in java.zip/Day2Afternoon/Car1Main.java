package com.Day2Afternoon;
public class Car1Main {
	public static void main(String[] args) {
		Car1 car = new Car1 ();
		car.setSpeed (10);
		car.setDoors ("closed");
		car.setEngine ("on");
		car.setDriver ("seated");
		//calling the function
		System.out.println (car.run ());
	}

}
