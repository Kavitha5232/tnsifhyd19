package com.Day2Afternoon;

public interface BankAccount {
	float rateofInterest();
}
