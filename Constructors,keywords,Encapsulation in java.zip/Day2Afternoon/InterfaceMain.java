package com.Day2Afternoon;

public interface InterfaceMain {
	public static void main(String[] args) {
		Animal a1 = new Pet();
		a1.test();
	}

}

