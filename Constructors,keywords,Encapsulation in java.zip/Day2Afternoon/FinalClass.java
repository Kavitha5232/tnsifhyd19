package com.Day2Afternoon;

public final class FinalClass {
void run() {
	System.out.println("running");
				
	}
}
