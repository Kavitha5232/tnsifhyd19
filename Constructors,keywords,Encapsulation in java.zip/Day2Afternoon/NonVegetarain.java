package com.Day2Afternoon;



	public class NonVegetarain extends Human {
		

		@Override
		public void eat() {
			System.out.println("Eats Nonveg");
		}

	}


