package com.Day2Afternoon;

public class TextSuper {
public static void main(String[] args) {
	Dog d=new Dog();
	d.printColor();

}
}
