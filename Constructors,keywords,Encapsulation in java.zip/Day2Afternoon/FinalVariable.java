package com.Day2Afternoon;


public class FinalVariable {
final int speedLimit=90;
void run() {
	int speed = 400;
}
public static void main(String[] args) {
	FinalVariable fv=new FinalVariable();
	fv.run();
	
	
}
	
}
