package com.Day2Afternoon;


public class AbstractClassMain {
	public static void main(String[] args) {
		Human john = new Vegetarain();
		john.speak();
		john.eat();
		System.out.println("=======================");
		Human hu = new NonVegetarain();
		hu.speak();
		hu.eat();
	}

}

