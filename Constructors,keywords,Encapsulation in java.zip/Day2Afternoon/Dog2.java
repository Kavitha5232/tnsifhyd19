package com.Day2Afternoon;

public class Dog2 extends SuperInvoke {
	void eat() {
		System.out.println("eating bread...");
	}
		void bark() {
			System.out.println("barking..");
		}
		void work() {
			super.eat();
			bark();
			
			
		
		}
	}


