package com.Day2Afternoon;

public interface Animal {
	
		
		public void test();

	}


