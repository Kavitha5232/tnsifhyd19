package com.Day2Afternoon;

public class TextSuper2 {
	public static void main(String[] args) {
		Dog2 d=new Dog2();
		d.work();
		
		
	} 
	}  


