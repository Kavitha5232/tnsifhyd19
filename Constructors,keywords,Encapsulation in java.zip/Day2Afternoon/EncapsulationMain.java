package com.Day2Afternoon;


public class EncapsulationMain {
	public static void main(String[] args) {
		Encapsulation e = new Encapsulation();
		e.setAge(25);
		e.setGender("Male");
		e.setName("John");
		
		System.out.println(e.getAge());
		System.out.println(e.getGender());
		System.out.println(e.getName());
		
	}

}

