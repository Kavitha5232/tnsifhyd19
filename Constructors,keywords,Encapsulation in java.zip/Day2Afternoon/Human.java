package com.Day2Afternoon;

public abstract class Human {
	public void speak() {
		System.out.println("Share his/her thougths");
	}
	
	public abstract void eat();

}


