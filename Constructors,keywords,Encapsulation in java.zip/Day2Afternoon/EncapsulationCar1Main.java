package com.Day2Afternoon;


public class EncapsulationCar1Main {
	public static void main(String[] args) {
		EncapsulationCar1 c1= new EncapsulationCar1();
		c1.setSpeed(50);
		System.out.println(c1.getSpeed());
		
		
		c1.setDoors("Closed");
		System.out.println(c1.getDoors());
		
		
		c1.setDrivers("Seated");
		System.out.println(c1.getDrivers());
		
	}

}

