package com.Day2Afternoon;

public class SuperConstructor {
SuperConstructor() 

	{
		System.out.println("animal is created");
	}
}
