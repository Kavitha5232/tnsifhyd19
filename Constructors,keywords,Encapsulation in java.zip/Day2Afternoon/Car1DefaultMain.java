package com.Day2Afternoon;



public class Car1DefaultMain {
	public static void main(String[] args) {
		Car1Default c1 = new Car1Default();
		System.out.println(c1.run());
	}

}

