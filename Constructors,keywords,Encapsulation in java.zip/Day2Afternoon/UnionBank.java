package com.Day2Afternoon;


public class UnionBank implements BankAccount{
	

		@Override
		public float rateofInterest() {
			// TODO Auto-generated method stub
			return 9.7f;
		}

	}
