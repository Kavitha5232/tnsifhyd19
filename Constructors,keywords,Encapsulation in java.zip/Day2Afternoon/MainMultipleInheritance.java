package com.Day2Afternoon;



public class MainMultipleInheritance {
	public static void main(String[] args) {
		BankAccount b1 = new AndhraBank();
		BankAccount i1 = new UnionBank();
		
		System.out.println(b1.rateofInterest());
		System.out.println(i1.rateofInterest());
	}

}

