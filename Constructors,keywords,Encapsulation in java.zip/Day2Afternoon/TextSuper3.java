package com.Day2Afternoon;

public class TextSuper3 {
	public static void main(String args[]){  
		DogConstructor d=new DogConstructor();  
		}} 


