package com.Day2Afternoon;



public class Vegetarain extends Human{
	
		
		@Override
		public void eat() {
			System.out.println("Eats veg");
		}

	}

