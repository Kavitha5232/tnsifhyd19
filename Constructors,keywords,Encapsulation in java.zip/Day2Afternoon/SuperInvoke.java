package com.Day2Afternoon;

public class SuperInvoke {
	void eat()
	{
		System.out.println("eating...");
	}
	}  



