package com.Day2Inheriatnce;


public class PolymorphismMainOverriding {
public static void main(String[] args) {
		
	ExtendsMOverriding e1 = new ExtendsMOverriding();
		e1.displayInfo();
		/*
		 * PolymorphismLanguage1MOverriding p2 = new PolymorphismLanguage1MOverriding();
		 * p2.displayInfo();
		 */
	}

}	

