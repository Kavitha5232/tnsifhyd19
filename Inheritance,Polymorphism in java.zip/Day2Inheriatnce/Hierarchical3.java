package com.Day2Inheriatnce;



public class Hierarchical3 extends Hierachical1 {
		
		 public void show() {
			 System.out.println(" I am a method from class C");
		 }

	}

