package com.Day2Inheriatnce;



public class Hierarchical2 extends Hierachical1 {
	
		
		public void print() {
			System.out.println("I am a method from class B");
		}

	}

