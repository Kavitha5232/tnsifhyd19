package com.Day2Inheriatnce;

public class MultiLevel1 {
	String getName() {
		return "progrramerBay";
	}

}

