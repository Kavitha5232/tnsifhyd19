package com.Day2Inheriatnce;

public class Hierachical1 {
	public void display() {
		System.out.println("I am method from class A");
	}

}
