package com.Day2Inheriatnce;



	public class SingleLevell extends SingleLevel{
		
		public void print() {
			
			System.out.println("I am a method from class B");
		}
		
		public static void main(String[] args) {
			
			SingleLevell obj = new SingleLevell();
			obj.display();
			obj.print();
			
		}

	}

