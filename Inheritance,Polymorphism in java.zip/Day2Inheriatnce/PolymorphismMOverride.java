package com.Day2Inheriatnce;

public class PolymorphismMOverride {
	public void displayInfo() {
	    System.out.println("Common English Language");
	  }

}

