package com.Day2Inheriatnce;

public class SingleLevel {
	public void display() {
		System.out.println("I am a method from class A");
	}

}

