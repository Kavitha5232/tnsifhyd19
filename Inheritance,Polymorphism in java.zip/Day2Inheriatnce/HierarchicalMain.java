package com.Day2Inheriatnce;



public class HierarchicalMain {
	public static void main(String[] args) {
		Hierarchical3 h3=new Hierarchical3();
		h3.display();
		
		
	}

}

