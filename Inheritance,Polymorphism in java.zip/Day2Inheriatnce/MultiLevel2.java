package com.Day2Inheriatnce;



public class MultiLevel2 extends MultiLevel1 {
	
		
		String getCodinglanguage() {
			return "Java";
		}

	}

