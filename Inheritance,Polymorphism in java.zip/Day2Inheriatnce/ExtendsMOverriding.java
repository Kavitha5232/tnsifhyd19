package com.Day2Inheriatnce;



public class ExtendsMOverriding extends PolymorphismMOverride {
	
		@Override
		  public void displayInfo() {
		    System.out.println("Java Programming Language");
		  }

	}

