package com.Day2Inheriatnce;



public class MultiLevel3 extends MultiLevel2{
	
		
		int getLineofCode() {
			return 20;
		}
		
		public static void main(String[] args) {
			MultiLevel3 mp3 = new MultiLevel3();
			System.out.println("I am "+mp3.getName()+" and I code in " + mp3.getCodinglanguage()+" . This Program has" + mp3.getLineofCode()+" lines");
		}

	}

