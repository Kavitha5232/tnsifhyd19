package com.Day2Inheriatnce;

public class MainMOverload {
	public static void main(String[] args) {
		PolymorphismMOverload m1 = new PolymorphismMOverload();
		m1.display();
		
		System.out.println("\n");
		
		m1.display('#');
	}

}
