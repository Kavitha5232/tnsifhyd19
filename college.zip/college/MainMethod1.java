package com.college;

public class MainMethod1 {
	public static void main(String[] args) {
		MethodOverloading m1 = new MethodOverloading();
		m1.display();
		
		System.out.println("\n");
		
		m1.display('#');
	}

}


