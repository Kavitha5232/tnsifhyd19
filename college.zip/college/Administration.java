package com.college;
import com.college.*;





public class Administration {
	public static void main(String[] args)
	{
		CSE c1=new CSE();
		ECE e1=new ECE();
		EEE E1=new EEE();
		c1.subject();
		c1.faculty();
		e1.subject();
		e1.faculty();
		E1.subject();
		E1.faculty();
		
	}

}
