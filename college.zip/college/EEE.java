package com.college;

public class EEE {
public void subject()
{
	System.out.println("Electric circuits");
}
public void faculty()
{
	System.out.println("Anjali");
}
}