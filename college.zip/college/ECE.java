package com.college;

public class ECE {
public void subject()
{
	System.out.println("Microprocessor");
}
public void faculty() {
	System.out.println("Vijaya");
}
}
