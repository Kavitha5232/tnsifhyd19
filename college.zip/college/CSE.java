package com.college;

public class CSE {
	public void subject()
	{
		System.out.println("Data structures");
	}
	public void faculty()
	{
		System.out.println("Ramesh");
	}
}
