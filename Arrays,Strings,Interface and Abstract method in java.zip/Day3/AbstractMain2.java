package com.Day3;

public class AbstractMain2 {
public static void main(String[] args) {
	AbstractBase d=new AbstractDerived();
	d.fun();
}
}