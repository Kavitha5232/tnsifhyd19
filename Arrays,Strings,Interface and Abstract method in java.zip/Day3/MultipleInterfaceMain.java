package com.Day3;

public class MultipleInterfaceMain {
	public static void main(String[] args) {
		DemoInterface di=new DemoInterface();
		di.mymethod();
		di.myOtherMethod();
		
	}

}
