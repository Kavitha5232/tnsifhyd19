package com.Day3;

public class AbstractDerived extends AbstractBase {
	void Derived()
	{
		System.out.println("Derived constructor called");
	}
	void fun()
	{
		System.out.println("Derived fun() called");
	}
	
	}
	


