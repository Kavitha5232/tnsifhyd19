package com.Day3;

public class StringEqualToOperator {
	public static void main(String args[]){  
		   String s1="Sachin";  
		   String s2="Sachin";  
		   String s3=new String("Sachin");  
		   System.out.println(s1==s2);
		   System.out.println(s1==s3);
		}  

}
