package com.Day3;

public class StringBuilderInsert {
public static void main(String[] args) {
	StringBuilder sb=new StringBuilder("Hello");
	sb.insert(1,"Java");
	System.out.println(sb);
	
}
}
