package com.Day3;

public class StringBuilderReplace {
	public static void main(String args[]){  
		StringBuilder sb=new StringBuilder("Hello");  
		sb.replace(1,3,"Java");  
		System.out.println(sb);//prints HJavalo  
		}  
		}  


