package com.Day3;

public class ArrayOfObjectsMain {
	
	    public static void main (String[] args)
	    {
	        
	        ArrayOfObjects[] arr;
	         arr = new ArrayOfObjects[5];
	        arr[0] = new ArrayOfObjects(1,"Kavitha");
	        arr[1] = new ArrayOfObjects(2,"Sneha");
	        arr[2] = new ArrayOfObjects(3,"Mounika");
	        arr[3] = new ArrayOfObjects(4,"Mona");
	        arr[4] = new ArrayOfObjects(5,"Shilpa");
	 
	      
	        for (int i = 0; i < arr.length; i++)
	            System.out.println("Element at " + i + " : " +
	                        arr[i].roll_no +" "+ arr[i].name);
	    }
	}

