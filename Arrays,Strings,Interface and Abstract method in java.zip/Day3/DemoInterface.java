package com.Day3;

public class DemoInterface implements MultipleInterface1,MultipleInterface2 {

	@Override
	public void myOtherMethod() {
		System.out.println("some other method");
	}

	@Override
	public void mymethod() {
		System.out.println("some method");
	}
}
	
