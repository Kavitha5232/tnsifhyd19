package com.Day3;

public class StringEquals2 {
	
		 public static void main(String args[]){  
		   String s1="Sachin";  
		   String s2="SACHIN";  
		  
		   System.out.println(s1.equals(s2));
		   System.out.println(s1.equalsIgnoreCase(s2));
		 }  
		} 


