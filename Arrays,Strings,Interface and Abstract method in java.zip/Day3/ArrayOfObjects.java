package com.Day3;

public class ArrayOfObjects {
public int roll_no;
public String name;
ArrayOfObjects(int roll_no,String name)
{
	this.roll_no=roll_no;
	this.name=name;
}
}
