package com.Day3;

public class Derived1 extends Base1 {
	void fun()
	{
		System.out.println("Derived fun() called");
		
	}

}
