package com.Day3;

public  abstract class Base1 {
	abstract void fun();
}


