package com.Day3;

public interface MultipleInterface1 {
public void mymethod();

}
