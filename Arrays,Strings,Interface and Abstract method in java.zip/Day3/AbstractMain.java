package com.Day3;

public class AbstractMain {
	public static void main(String[] args){
		Base1 b=new Derived1();
		b.fun();
		
		
	}
}
