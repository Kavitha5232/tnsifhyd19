package com.Day3;

public interface MultipleInterface2 {
	public void myOtherMethod();
}
