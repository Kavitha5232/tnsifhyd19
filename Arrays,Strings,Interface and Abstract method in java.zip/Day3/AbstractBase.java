package com.Day3;

public abstract class AbstractBase {
	void Base()
	
	{
		System.out.println("Base constructor called");
		
	}
abstract void fun();
}

