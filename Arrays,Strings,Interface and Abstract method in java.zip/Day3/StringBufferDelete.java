package com.Day3;

public class StringBufferDelete {
	public static void main(String args[]){  
		StringBuffer sb=new StringBuffer("Hello");  
		sb.delete(1,3);  
		System.out.println(sb);
	}
		}  


