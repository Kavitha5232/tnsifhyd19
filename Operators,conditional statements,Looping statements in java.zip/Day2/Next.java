package com.Day2;
import java.util.Scanner;
public class Next {
	  public static void main(String[] args) {
		   
		   Scanner input = new Scanner(System.in);
		    System.out.print("Enter your name: ");
		   
		    String value = input.next();
		    System.out.println("Using next(): " + value);
		    input.close();
		  }
		}
