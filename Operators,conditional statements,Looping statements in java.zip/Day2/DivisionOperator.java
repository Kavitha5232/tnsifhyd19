package com.Day2;

public class DivisionOperator {
public static void main(String[] args) {
	int x=1;
	int y=56/4;
	System.out.println(y);
	
}
}
