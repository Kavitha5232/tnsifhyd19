package com.Day2;

public class BitwiseCompliment {
	
	    public static void main(String[] args) {
	        int a = 12;  // Binary: 00000000 00000000 00000000 00001100
	        
	        // Bitwise Complement
	        int result = ~a;  // Binary: 11111111 11111111 11111111 11110011, Decimal: -13
	        System.out.println("~a: " + result);
	    }
	}


