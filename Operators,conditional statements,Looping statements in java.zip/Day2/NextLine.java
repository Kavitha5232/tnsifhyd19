package com.Day2;
import java.util.Scanner;
public class NextLine {
	public static void main(String[] args) {
	   Scanner input = new Scanner(System.in);
	    System.out.print("Enter your name: ");
	     String value = input.nextLine();
	    System.out.println("Using nextLine(): " + value);
	    input.close();
	  }
	}


