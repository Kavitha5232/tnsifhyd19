package com.Day2;

public class RelationalLessEqualTo {
	    public static void main(String[] args) {
	        int a = 15;
	        int b = 20;
	        
	        // Less than or equal to
	        boolean result = (a <= b);  // result will be true because a is less than b
	        System.out.println("a <= b: " + result);
	    }
	}


