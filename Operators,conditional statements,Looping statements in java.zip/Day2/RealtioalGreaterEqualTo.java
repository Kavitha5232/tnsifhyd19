package com.Day2;

public class RealtioalGreaterEqualTo {
	
	    public static void main(String[] args) {
	        int a = 20;
	        int b = 20;
	        
	        // Greater than or equal to
	        boolean result = (a >= b);  // result will be true because a is equal to b
	        System.out.println("a >= b: " + result);
	    }
	}

