package com.Day2;

public class LogicalOR {
	
	    public static void main(String[] args) {
	        boolean a = true;
	        boolean b = false;
	        
	        // Logical OR
	        boolean result = a || b;  // result will be true because a is true
	        System.out.println("a || b: " + result);
	    }
	}
