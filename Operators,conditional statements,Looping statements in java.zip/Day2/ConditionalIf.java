package com.Day2;

public class ConditionalIf {
	public static void main(String[] args) {
		int num=20;
		if(num>0){  
	        System.out.print("Positive");  
	    }  
	}  
	}

		
	
