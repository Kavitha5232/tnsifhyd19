package com.Day2;

public class AssignmentOperator {
public static void main(String[] args) {
	int x=5;
	//x +=5;
	//x -=5;
	//x *=5;
	//x /=5;
	x %=5;
	System.out.println(x);
}
}
