package com.Day2;

public class RelationalEqualTo {
	
	    public static void main(String[] args) {
	        int a = 10;
	        int b = 10;
	        
	        // Equal to
	        boolean result = (a == b);  // result will be true because a is equal to b
	        System.out.println("a == b: " + result);
	    }
	}

