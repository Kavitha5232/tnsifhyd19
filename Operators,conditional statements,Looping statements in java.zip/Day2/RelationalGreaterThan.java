package com.Day2;

public class RelationalGreaterThan {
	
	    public static void main(String[] args) {
	        int a = 20;
	        int b = 15;
	        
	        // Greater than
	        boolean result = (a > b);  // result will be true because a is greater than b
	        System.out.println("a > b: " + result);
	    }
	}


