package com.Day2;

public class TernaryOperator {
public static void main(String[] args) {
	boolean x;
	x=(10<9)?true:false;
	System.out.println(x);






int age=12;
String a="Allowed to vote";
String b="Not Allowed to vote";
String accessallowed=(age>18)?a:b;
System.out.println(accessallowed);
}
}