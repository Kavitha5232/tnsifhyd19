package com.Day2;

public class BitwiseOR {
	
	    public static void main(String[] args) {
	        int a = 12;  // Binary: 1100
	        int b = 7;   // Binary: 0111
	        
	        // Bitwise OR
	        int result = a | b;  // Binary: 1111, Decimal: 15
	        System.out.println("a | b: " + result);
	    }
	}


