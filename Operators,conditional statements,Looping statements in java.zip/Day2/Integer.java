package com.Day2;
import java.util.Scanner;
public class Integer {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.print("Enter an integer");
		int data1=scanner.nextInt();
		System.out.println("Using nextInt():"+data1);
		scanner.close();
		
	}

}
