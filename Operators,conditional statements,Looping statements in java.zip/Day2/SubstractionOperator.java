package com.Day2;

public class SubstractionOperator {
public static void main(String[] args) {
	int x=1;
	int y=12-x;
	System.out.println(y);
	
	
}
}
