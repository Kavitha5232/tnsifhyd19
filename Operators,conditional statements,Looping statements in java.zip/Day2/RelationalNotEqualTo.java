package com.Day2;

public class RelationalNotEqualTo {
	
	    public static void main(String[] args) {
	        int a = 10;
	        int b = 15;
	        
	        // Not equal to
	        boolean result = (a != b);  // result will be true because a is not equal to b
	        System.out.println("a != b: " + result);
	    }
	}


