package com.Day2;

public class LogicalAND {
	
	    public static void main(String[] args) {
	        boolean a = true;
	        boolean b = false;
	        
	        
	        boolean result = a && b;  // result will be false because b is false
	        System.out.println("a && b: " + result);
	    }
	}



