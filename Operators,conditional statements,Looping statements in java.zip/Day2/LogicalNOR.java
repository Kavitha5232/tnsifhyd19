package com.Day2;

public class LogicalNOR {
	
	    public static void main(String[] args) {
	        boolean a = true;
	        
	        // Logical NOT
	        boolean result = !a;  // result will be false because a is true
	        System.out.println("!a: " + result);
	    }
	}

