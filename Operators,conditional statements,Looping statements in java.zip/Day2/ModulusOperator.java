package com.Day2;

public class ModulusOperator {
	public static void main(String[] args) {
		int mod =23%2;
		System.out.println(mod);
	}

}
