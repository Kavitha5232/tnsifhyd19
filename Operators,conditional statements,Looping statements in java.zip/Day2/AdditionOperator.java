package com.Day2;

public class AdditionOperator {
public static void main(String[] args) {
	int x=1+2;
	String s="Hello"+ "world";
	System.out.println(x);
	System.out.println(s);
}
}
	