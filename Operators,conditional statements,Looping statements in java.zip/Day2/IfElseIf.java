package com.Day2;

public class IfElseIf {
	public static void main(String[] args) {  
	    int num=0;  
	      
	    if(num<0){  
	        System.out.println("Negative");  
	    }  
	    else if(num>0){  
	        System.out.println("Positive");  
	      
	    }else {
	    	
	        System.out.println("Neither Negative nor Positive");  
	    }  
	}  


}
