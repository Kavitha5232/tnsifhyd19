package com.Day2;

public class BitwiseXOR {
	
	    public static void main(String[] args) {
	        int a = 12;  // Binary: 1100
	        int b = 7;   // Binary: 0111
	        
	        // Bitwise XOR
	        int result = a ^ b;  // Binary: 1011, Decimal: 11
	        System.out.println("a ^ b: " + result);
	    }
	}


