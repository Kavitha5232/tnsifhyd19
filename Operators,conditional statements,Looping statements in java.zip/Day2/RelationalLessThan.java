package com.Day2;

public class RelationalLessThan {
	
	    public static void main(String[] args) {
	        int a = 10;
	        int b = 20;
	        
	        // Less than
	        boolean result = (a < b);  // result will be true because a is less than b
	        System.out.println("a < b: " + result);
	    }
	}


