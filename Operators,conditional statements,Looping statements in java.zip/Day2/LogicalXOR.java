package com.Day2;

public class LogicalXOR {

	    public static void main(String[] args) {
	        boolean a = true;
	        boolean b = false;
	        
	        // Logical XOR
	        boolean result = a ^ b;  // result will be true because one is true and the other is false
	        System.out.println("a ^ b: " + result);
	    }
	}

