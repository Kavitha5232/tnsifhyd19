package com.Day2;
import java.util.Scanner;
public class Double {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.print("Enter Double value");
		double value=scanner.nextDouble();
		System.out.println("Using nextDouble():"+value);
		scanner.close();
		
	}

}
