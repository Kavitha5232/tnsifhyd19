package com.Day2;

public class MultiplicationOperator {
public static void main(String[] args) {
	int x=1;
	int y=12*3;
	System.out.println(y);
}
}
