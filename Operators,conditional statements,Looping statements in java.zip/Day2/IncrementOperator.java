package com.Day2;

public class IncrementOperator {
public static void main(String[] args) {
	int x=10;
	//System.out.println(x++); //postfix
	System.out.println(++x); //prefix
	
	
}
}
