package com.inheritance;

public class SingleInheritance {
	public static void main(String[] args) {
		Dog d1=new Dog();
		d1.bark();
		d1.eat();
		
		
	}

}
