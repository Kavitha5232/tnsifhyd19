package com.inheritance;

class Dog3 extends Animal3 {
void bark() {
	System.out.println("barking");
	
}
}
