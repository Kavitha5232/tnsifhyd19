package com.inheritance;

public class Animal3 {
	void eat() {
		System.out.println("eating");
		
	}

}
