package com.inheritance;
 class Dog extends Animal {
	 void bark() {
		 System.out.println("barking");
		 
	 }

}
