package com.inheritance;

 class BabyDog extends Dog {
	 void sweep() {
		 System.out.println("sweeping");
		 
	 }

}
