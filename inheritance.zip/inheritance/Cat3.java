package com.inheritance;

 class Cat3 extends Animal3 {
	 void meow() {
		 System.out.println("meowing");
		 
	 }

}
