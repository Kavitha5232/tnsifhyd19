package com.inheritance;

 class Dog2 extends Animal2 {
	 void bark() {
		 System.out.println("barking");
	 }

}
