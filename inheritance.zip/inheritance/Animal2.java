package com.inheritance;

public class Animal2 {
	void eat() {
		System.out.println("eating");
		
	}

}
