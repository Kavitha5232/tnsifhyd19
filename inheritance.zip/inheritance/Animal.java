package com.inheritance;

public class Animal {
	void eat()
	{
		System.out.println("eating");
	}
}