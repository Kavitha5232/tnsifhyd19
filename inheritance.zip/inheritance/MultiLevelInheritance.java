package com.inheritance;

public class MultiLevelInheritance {
	public static void main(String[] args) {
		BabyDog b1=new BabyDog();
    b1.sweep();
    b1.bark();
    
		
	}

}
