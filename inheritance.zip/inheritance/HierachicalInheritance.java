package com.inheritance;

public class HierachicalInheritance {
	public static void main(String[] args) {
		Cat3 c1=new Cat3();
		c1.meow();
		c1.eat();
		
	}

}
