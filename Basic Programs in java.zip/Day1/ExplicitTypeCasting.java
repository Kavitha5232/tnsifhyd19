package com.Day1;

public class ExplicitTypeCasting {
	public static void main(String[] args) {
		
	
	double f1 = 10.52f;
	long l = (long) f1;
    System.out.println(l);

	long l1 = 923372036854775806l;
	int i2 = (int) l1;
	System.out.println(i2);

	float f2 = 34.56f;
	int i1 = (int) f2;
	System.out.println(i1);

	byte b1 = 90;
	char ch1 = (char) b1;
	System.out.println(ch1);
}
}


