package com.Day1;
import java.util.Scanner;
public class Palindrome {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.print("Enter a string");
		String str=scanner.nextLine();
		String reversedstr="";
		for(int i=str.length()-1;i>=0;i--) {
			reversedstr +=str.charAt(i);
			
		}
		if(str.equals(reversedstr)) {
			System.out.print(str + "is a palindrome.");
		}else {
			System.out.print(str + "is not a palindrome.");
			
		}
	}

}
