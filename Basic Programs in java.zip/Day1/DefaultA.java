package com.Day1;

public class DefaultA {
	void display() {
		System.out.println("TNS sessions");
	}


}
