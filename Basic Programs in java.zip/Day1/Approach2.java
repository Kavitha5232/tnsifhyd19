package com.Day1;
public class Approach2 {
int a=10;
static int b=20;
void display()
{
	System.out.println(a);
}
static String display1()
{
	return "values";
	
}

public static void main(String[] args) {
	
	Approach2 a1 = new Approach2(); // creating objects
	
	//Accessing instance members(variable+methods)
	
	System.out.println(a1.a); //accessing instance variable through objects
	a1.display(); //accessing instance method through objects
	
	
	System.out.println("**************************************");
	
	// Accessing static members(variable+methods)
	
	System.out.println(Approach2.b); // Accessing static variable through class
	Approach2.display1(); // By specifying classname.method() we can access static method.
	
}
}


