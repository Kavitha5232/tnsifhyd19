package com.Day1;

public class ImplicitTypeCasting {
	public static void main(String[] args) {
      byte b = 10;
		int i = b;
		System.out.println(i);
		float f = 22.14f;
		double d = f;
		System.out.println(d);
		char ch = 'A';
		int i3 = ch;
		System.out.println(i3);
		char var1 = '\u00A7';
		int i4 = var1;
		System.out.println(i4);
}
}