package com.Day1;

public class Approach1 {
int a=10;
static int b=20;
public static void main(String[] args) {
	int c=30;
	Approach1 a1=new Approach1();
	System.out.println(a1.a);
	System.out.println(Approach1.b);
}
}
	
	
