package com.Day1;
public class PrivateA{
	
	private void display()
	{
	System.out.println("TNS Sessions");
	}
}