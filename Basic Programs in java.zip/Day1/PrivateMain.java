package com.Day1;
public class PrivateMain {
	public static void main(String[] args) {
		PrivateA a = new PrivateA();
		a.display();
	}

}
