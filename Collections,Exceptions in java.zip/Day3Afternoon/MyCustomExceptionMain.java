package com.Day3Afternoon;

public class MyCustomExceptionMain {
	private static final String String = null;

	public static void main(String[] args) {
		try {
			
		throw new MyCustomException(String);
    }  
    catch (MyCustomException ex)  
    {  
        System.out.println("Caught the exception");  
        System.out.println(ex.getMessage());  
    }  

    System.out.println("rest of the code...");    

		
	}

}
