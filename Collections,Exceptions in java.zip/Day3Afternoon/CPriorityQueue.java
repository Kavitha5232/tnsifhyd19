package com.Day3Afternoon;

import java.util.PriorityQueue;

public class CPriorityQueue {
	
	    public static void main(String args[])
	    {
	        // Creating empty priority queue
	        PriorityQueue<Integer> pQueue
	            = new PriorityQueue<Integer>();
	  
	        
	        pQueue.add(1);
	        pQueue.add(2);
	        pQueue.add(3);
	        System.out.println(pQueue.peek());
	        
	       
	        System.out.println(pQueue.poll());
	  
	        // Printing the top element again
	        System.out.println(pQueue.peek());
	    }
	}

