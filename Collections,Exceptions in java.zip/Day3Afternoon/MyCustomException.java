package com.Day3Afternoon;

public class MyCustomException extends Exception
{
	public MyCustomException(String str)
	{
		super();
		
	}

}
