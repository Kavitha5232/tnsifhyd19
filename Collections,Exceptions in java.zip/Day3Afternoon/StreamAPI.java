package com.Day3Afternoon;


	import java.util.Arrays;
	import java.util.List;
	import java.util.stream.Collectors;

	public class StreamAPI {
	    public static void main(String[] args) {
	        List<String> names = Arrays.asList("Alice", "Bob", "Charlie", "David", "Edward");

	        // Filter names that start with 'A' and collect them into a new list
	        List<String> filteredNames = names.stream()
	                                          .filter(name -> name.startsWith("A"))
	                                          .collect(Collectors.toList());

	        System.out.println(filteredNames);
	    }
	}

